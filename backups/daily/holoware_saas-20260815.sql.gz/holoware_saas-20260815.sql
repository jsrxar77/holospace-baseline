--
-- PostgreSQL database dump
--

\restrict zFYv80mxLu5lBhqMA6MRWfcJeVnyxaXGaFutXJxUyCT9wnT6jDtuX2wORgu2kl7

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: holoware_admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO holoware_admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: holoware_admin
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.app_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    key character varying(128) NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.app_settings OWNER TO holoware_admin;

--
-- Name: modules; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.modules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(64) DEFAULT 'operational'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    activated_by character varying(255) DEFAULT 'system'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.modules OWNER TO holoware_admin;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    order_id uuid NOT NULL,
    code character varying(64) NOT NULL,
    description text NOT NULL,
    quantity_required integer DEFAULT 1 NOT NULL,
    quantity_scanned integer DEFAULT 0 NOT NULL,
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    scanned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.order_items OWNER TO holoware_admin;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    order_number character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'BACKLOG'::character varying NOT NULL,
    client_name character varying(255) NOT NULL,
    total_items integer DEFAULT 0 NOT NULL,
    total_items_scanned integer DEFAULT 0 NOT NULL,
    assigned_operator_email character varying(255) DEFAULT NULL::character varying,
    verified_by character varying(255) DEFAULT NULL::character varying,
    verified_at timestamp with time zone,
    dispatch_status character varying(64) DEFAULT 'NO_DESPACHADO'::character varying,
    dispatch_tracking character varying(255) DEFAULT NULL::character varying,
    pdf_blob bytea,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['BACKLOG'::character varying, 'READY'::character varying, 'DOING'::character varying, 'DONE'::character varying, 'CLOSED'::character varying, 'PARTIAL_DISPATCH'::character varying])::text[])))
);


ALTER TABLE public.orders OWNER TO holoware_admin;

--
-- Name: platform_audit_logs; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.platform_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    user_email character varying(255) DEFAULT NULL::character varying,
    action character varying(128) NOT NULL,
    module_code character varying(64) DEFAULT 'core'::character varying,
    details jsonb DEFAULT '{}'::jsonb,
    ip_address character varying(64) DEFAULT NULL::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.platform_audit_logs OWNER TO holoware_admin;

--
-- Name: tenant_modules; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.tenant_modules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    module_code character varying(64) NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    quota_limit integer,
    quota_used integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_modules_module_code_check CHECK (((module_code)::text = ANY ((ARRAY['tenants'::character varying, 'core'::character varying, 'scanban-board'::character varying, 'scanban-scanner'::character varying, 'scanflow'::character varying, 'scanban'::character varying, 'stockflow'::character varying, 'analytics'::character varying])::text[])))
);


ALTER TABLE public.tenant_modules OWNER TO holoware_admin;

--
-- Name: tenant_subscriptions; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.tenant_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    plan_code character varying(64) DEFAULT 'starter'::character varying NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    max_users integer DEFAULT 5 NOT NULL,
    max_orders_monthly integer DEFAULT 500 NOT NULL,
    current_period_start timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    current_period_end timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '30 days'::interval),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_subscriptions_plan_code_check CHECK (((plan_code)::text = ANY ((ARRAY['starter'::character varying, 'pro'::character varying, 'enterprise'::character varying])::text[]))),
    CONSTRAINT tenant_subscriptions_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'past_due'::character varying, 'canceled'::character varying, 'trialing'::character varying])::text[])))
);


ALTER TABLE public.tenant_subscriptions OWNER TO holoware_admin;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    custom_domain character varying(255) DEFAULT NULL::character varying,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenants_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'trial'::character varying, 'canceled'::character varying])::text[])))
);


ALTER TABLE public.tenants OWNER TO holoware_admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: holoware_admin
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(32) DEFAULT 'OPERATOR'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    theme_preference character varying(64) DEFAULT NULL::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['SUPERADMIN'::character varying, 'ADMIN'::character varying, 'OPERATOR'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO holoware_admin;

--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.app_settings (id, tenant_id, key, value, created_at, updated_at) FROM stdin;
4c77a543-974c-4c0f-9a6c-e4d1fd3bc4a8	a0000000-0000-0000-0000-000000000001	active_theme	omarchy_tiling	2026-08-14 22:59:18.718176+00	2026-08-14 22:59:18.718176+00
bd6119f3-e320-4359-9420-f926a7a309e4	550e8400-e29b-41d4-a716-446655440000	active_theme	omarchy_tiling	2026-08-14 22:59:18.719741+00	2026-08-14 22:59:18.719741+00
ebe878f8-5e4c-4aaf-9734-5e27e8e7d1b8	550e8400-e29b-41d4-a716-446655440001	active_theme	omarchy_tiling	2026-08-14 22:59:18.721209+00	2026-08-14 22:59:18.721209+00
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.modules (id, key, name, description, category, is_active, activated_by, created_at) FROM stdin;
01d606fd-4eaf-4423-bf8e-99bb6b4bd480	tenants	Gestión Multi-Tenant	Panel exclusivo SUPERADMIN para administración de organizaciones, cuotas y licencias.	admin	t	system	2026-08-14 22:59:18.71542+00
84a050a7-8313-445f-b2cf-f8074769e0fe	core	HoloWare Core	Plataforma base: autenticación centralizada, motor de temas y auditoría.	system	t	system	2026-08-14 22:59:18.71542+00
017ce0c6-9d6f-403f-963c-b0472765325a	scanban-board	ScanBan Board	Módulo Web de logística: Tablero Kanban 4 columnas y explorador de pedidos.	operational	t	system	2026-08-14 22:59:18.71542+00
83e5552a-a2e8-4f3d-b278-124e5b861d33	scanban-scanner	ScanBan Scanner	Módulo Móvil Expo: Escáner de códigos de barra EAN-13 y validación de depósito.	operational	t	system	2026-08-14 22:59:18.71542+00
09ca95e2-67d2-45fc-ae6e-eef9336d4578	scanflow	ScanFlow	Módulo de inventario y stock: control de existencias, ubicaciones y movimientos.	operational	t	system	2026-08-14 22:59:18.71542+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.order_items (id, tenant_id, order_id, code, description, quantity_required, quantity_scanned, status, scanned_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.orders (id, tenant_id, order_number, status, client_name, total_items, total_items_scanned, assigned_operator_email, verified_by, verified_at, dispatch_status, dispatch_tracking, pdf_blob, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_audit_logs; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.platform_audit_logs (id, tenant_id, user_email, action, module_code, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_modules; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.tenant_modules (id, tenant_id, module_code, is_enabled, quota_limit, quota_used, created_at, updated_at) FROM stdin;
b158b8e6-73c1-4cb6-a704-217992db3b3c	a0000000-0000-0000-0000-000000000001	tenants	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
a68acd17-31c5-4169-9fa5-5d83b6382665	a0000000-0000-0000-0000-000000000001	core	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
4cb456fb-da99-4c27-b443-dd50285659cb	a0000000-0000-0000-0000-000000000001	scanban-board	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
11b6151e-2101-4c28-b6b6-c025a09932d3	a0000000-0000-0000-0000-000000000001	scanban-scanner	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
9c107509-7c39-42b8-bf3d-7d469a43ec42	a0000000-0000-0000-0000-000000000001	scanflow	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
918aca78-b1b2-445c-a80c-acdbe1ddfa19	a0000000-0000-0000-0000-000000000001	scanban	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
792b953e-b7fd-4d0e-81a5-e6859aa98b0f	a0000000-0000-0000-0000-000000000001	stockflow	t	\N	0	2026-08-14 22:59:18.716303+00	2026-08-14 22:59:18.716303+00
2d1321b0-9eef-4847-8512-1a3a3209dbbc	550e8400-e29b-41d4-a716-446655440000	core	t	\N	0	2026-08-14 22:59:18.719419+00	2026-08-14 22:59:18.719419+00
fffd7f88-9c18-4da4-8ff1-0c28a3fc021a	550e8400-e29b-41d4-a716-446655440000	scanban-board	t	\N	0	2026-08-14 22:59:18.719419+00	2026-08-14 22:59:18.719419+00
469707ef-ea16-42f0-b5ab-d96590b59694	550e8400-e29b-41d4-a716-446655440000	scanban-scanner	t	\N	0	2026-08-14 22:59:18.719419+00	2026-08-14 22:59:18.719419+00
c4c521a5-eda9-4e03-b068-cbe1033da793	550e8400-e29b-41d4-a716-446655440000	scanban	t	\N	0	2026-08-14 22:59:18.719419+00	2026-08-14 22:59:18.719419+00
6a920bef-7961-4aee-afeb-f35e76155a2d	550e8400-e29b-41d4-a716-446655440001	core	t	\N	0	2026-08-14 22:59:18.720906+00	2026-08-14 22:59:18.720906+00
e0a33f78-80fc-40d8-abad-4bbe6b62ef56	550e8400-e29b-41d4-a716-446655440001	scanban-board	t	\N	0	2026-08-14 22:59:18.720906+00	2026-08-14 22:59:18.720906+00
f4e27e00-fe14-490e-b3de-3b0f39a60de3	550e8400-e29b-41d4-a716-446655440001	scanban-scanner	t	\N	0	2026-08-14 22:59:18.720906+00	2026-08-14 22:59:18.720906+00
2a4e3fab-ae1e-4a97-a987-a48855b21147	550e8400-e29b-41d4-a716-446655440001	scanban	t	\N	0	2026-08-14 22:59:18.720906+00	2026-08-14 22:59:18.720906+00
\.


--
-- Data for Name: tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.tenant_subscriptions (id, tenant_id, plan_code, status, max_users, max_orders_monthly, current_period_start, current_period_end, created_at, updated_at) FROM stdin;
ae68e321-97de-438c-81cc-df8e6a7ca3ef	a0000000-0000-0000-0000-000000000001	enterprise	active	999	999999	2026-08-14 22:59:18.714394+00	2026-09-13 22:59:18.714394+00	2026-08-14 22:59:18.714394+00	2026-08-14 22:59:18.714394+00
a14758a1-a656-41eb-817c-1d177b0e7f24	550e8400-e29b-41d4-a716-446655440000	pro	active	15	3000	2026-08-14 22:59:18.719054+00	2026-09-13 22:59:18.719054+00	2026-08-14 22:59:18.719054+00	2026-08-14 22:59:18.719054+00
11025046-8168-481e-825a-39b24ab92027	550e8400-e29b-41d4-a716-446655440001	pro	active	15	3000	2026-08-14 22:59:18.720626+00	2026-09-13 22:59:18.720626+00	2026-08-14 22:59:18.720626+00	2026-08-14 22:59:18.720626+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.tenants (id, slug, name, custom_domain, status, settings, created_at, updated_at) FROM stdin;
a0000000-0000-0000-0000-000000000001	holoware	HoloWare Cloud Platform	\N	active	{}	2026-08-14 22:59:18.713474+00	2026-08-14 22:59:18.713474+00
550e8400-e29b-41d4-a716-446655440000	drinklovers	Drink Lovers Argentina	\N	active	{}	2026-08-14 22:59:18.718773+00	2026-08-14 22:59:18.718773+00
550e8400-e29b-41d4-a716-446655440001	poke	Poke Argentina	\N	active	{}	2026-08-14 22:59:18.720372+00	2026-08-14 22:59:18.720372+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: holoware_admin
--

COPY public.users (id, tenant_id, email, password_hash, name, role, is_active, theme_preference, created_at, updated_at) FROM stdin;
030568b7-8693-4428-8b80-2a7f3a334a61	a0000000-0000-0000-0000-000000000001	superadmin@hologrowth.com.ar	scrypt:BrunaSeRelambe22!	Super Administrador Global	SUPERADMIN	t	\N	2026-08-14 22:59:18.717347+00	2026-08-14 22:59:18.717347+00
47d7280c-607d-4aa3-be2d-581d70db4991	550e8400-e29b-41d4-a716-446655440000	admin@drinklovers.com.ar	scrypt:drinklovers2026	Admin DrinkLovers	ADMIN	t	\N	2026-08-14 22:59:18.720023+00	2026-08-14 22:59:18.720023+00
626233b4-00c4-4aa8-8d72-7902641ad7bb	550e8400-e29b-41d4-a716-446655440000	juan@drinklovers.com.ar	scrypt:juan2026	Juan (Operario DrinkLovers)	OPERATOR	t	\N	2026-08-14 22:59:18.720023+00	2026-08-14 22:59:18.720023+00
775fdeb6-fa8d-478e-adae-95bdd8fc6cd4	550e8400-e29b-41d4-a716-446655440000	vanesa@drinklovers.com.ar	scrypt:vanesa2026	Vanesa (Operaria DrinkLovers)	OPERATOR	t	\N	2026-08-14 22:59:18.720023+00	2026-08-14 22:59:18.720023+00
e6426df4-e2a0-4139-9e22-d58e94ee3538	550e8400-e29b-41d4-a716-446655440001	admin@poke.com.ar	scrypt:poke2026	Admin Poke	ADMIN	t	\N	2026-08-14 22:59:18.721501+00	2026-08-14 22:59:18.721501+00
10532ab1-dfed-4340-a29b-83616c55942c	550e8400-e29b-41d4-a716-446655440001	juan@poke.com.ar	scrypt:juan2026	Juan (Operario Poke)	OPERATOR	t	\N	2026-08-14 22:59:18.721501+00	2026-08-14 22:59:18.721501+00
a338a95a-2efe-4776-b671-f04a863df36e	550e8400-e29b-41d4-a716-446655440001	vanesa@poke.com.ar	scrypt:vanesa2026	Vanesa (Operaria Poke)	OPERATOR	t	\N	2026-08-14 22:59:18.721501+00	2026-08-14 22:59:18.721501+00
\.


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_tenant_id_key_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_tenant_id_key_key UNIQUE (tenant_id, key);


--
-- Name: modules modules_key_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_key_key UNIQUE (key);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_tenant_id_order_number_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_tenant_id_order_number_key UNIQUE (tenant_id, order_number);


--
-- Name: platform_audit_logs platform_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_modules tenant_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT tenant_modules_pkey PRIMARY KEY (id);


--
-- Name: tenant_modules tenant_modules_tenant_id_module_code_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT tenant_modules_tenant_id_module_code_key UNIQUE (tenant_id, module_code);


--
-- Name: tenant_subscriptions tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_key UNIQUE (tenant_id);


--
-- Name: tenants tenants_custom_domain_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_custom_domain_key UNIQUE (custom_domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: idx_audit_tenant_date; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_audit_tenant_date ON public.platform_audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_items_code; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_items_code ON public.order_items USING btree (code);


--
-- Name: idx_items_tenant_order; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_items_tenant_order ON public.order_items USING btree (tenant_id, order_id);


--
-- Name: idx_modules_key; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_modules_key ON public.modules USING btree (key);


--
-- Name: idx_orders_tenant_number; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_orders_tenant_number ON public.orders USING btree (tenant_id, order_number);


--
-- Name: idx_orders_tenant_status; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_orders_tenant_status ON public.orders USING btree (tenant_id, status);


--
-- Name: idx_settings_tenant_key; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_settings_tenant_key ON public.app_settings USING btree (tenant_id, key);


--
-- Name: idx_subscriptions_tenant; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_subscriptions_tenant ON public.tenant_subscriptions USING btree (tenant_id);


--
-- Name: idx_tenant_modules_lookup; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_tenant_modules_lookup ON public.tenant_modules USING btree (tenant_id, module_code);


--
-- Name: idx_tenants_slug; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_tenant_email; Type: INDEX; Schema: public; Owner: holoware_admin
--

CREATE INDEX idx_users_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: app_settings app_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: orders orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: platform_audit_logs platform_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_modules tenant_modules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_modules
    ADD CONSTRAINT tenant_modules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: holoware_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: platform_audit_logs; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.platform_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings rls_app_settings_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_app_settings_isolation ON public.app_settings USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: platform_audit_logs rls_audit_logs_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_audit_logs_isolation ON public.platform_audit_logs USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: order_items rls_order_items_tenant_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_order_items_tenant_isolation ON public.order_items USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: orders rls_orders_tenant_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_orders_tenant_isolation ON public.orders USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: tenant_modules rls_tenant_modules_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_tenant_modules_isolation ON public.tenant_modules USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: users rls_users_tenant_isolation; Type: POLICY; Schema: public; Owner: holoware_admin
--

CREATE POLICY rls_users_tenant_isolation ON public.users USING (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid))) WITH CHECK (((current_setting('app.is_superadmin'::text, true) = 'true'::text) OR (tenant_id = (NULLIF(current_setting('app.current_tenant_id'::text, true), ''::text))::uuid)));


--
-- Name: tenant_modules; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.tenant_modules ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: holoware_admin
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: holoware_admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict zFYv80mxLu5lBhqMA6MRWfcJeVnyxaXGaFutXJxUyCT9wnT6jDtuX2wORgu2kl7

